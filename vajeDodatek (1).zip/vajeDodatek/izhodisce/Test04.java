
public class Test04 {

    public static void main(String[] args) {
        System.out.println(Deljivost.delitelji(42));
        System.out.println(Deljivost.delitelji(25));
        System.out.println(Deljivost.delitelji(1));
        System.out.println(Deljivost.delitelji(23));
    }
}
