
public class Test07 {

    public static void main(String[] args) {
        System.out.println(Deljivost.prastevila(1, 10));
        System.out.println(Deljivost.prastevila(20, 100));
        System.out.println(Deljivost.prastevila(900, 1000));
        System.out.println(Deljivost.prastevila(90, 96));
        System.out.println(Deljivost.prastevila(70, 69));
    }
}
