
public class Test09 {

    public static void main(String[] args) {
        System.out.println(Deljivost.seznamiDeliteljev(1, 10));
        System.out.println(Deljivost.seznamiDeliteljev(20, 50));
        System.out.println(Deljivost.seznamiDeliteljev(36, 36));
        System.out.println(Deljivost.seznamiDeliteljev(36, 35));
    }
}
