
import java.util.*;
import java.util.function.*;

public class Deljivost {

    public static void main(String[] args) {
        // po potrebi dopolnite ...
    }

    public static <T> List<T> filtriraj(Collection<T> zbirka, Predicate<T> pogoj) {
		List<T> seznam = new ArrayList<>();
		for (T element: zbirka) {
			if (pogoj.test(element)) {
				seznam.add(element);
			}
		}
		return seznam;		
    }

    public static <T, R> List<R> pretvori(Collection<T> zbirka, Function<T, R> pretvornik) {
		List<R> seznam = new ArrayList<>();
		for (T element: zbirka) {
			R rezultatPretvorbe = pretvornik.apply(element);
			seznam.add(rezultatPretvorbe);
		}
		return seznam;
    }

    public static List<Integer> zaporedje(int a, int b) {
		List<Integer> seznam = new ArrayList<>();
		for (int i = a;  i <= b;  i++) {
			seznam.add(i);
		}
		return seznam;
    }

    public static List<Integer> delitelji(int n) {
        return filtriraj(zaporedje(1, n), element -> n % element == 0);
    }

    public static NavigableSet<Integer> skupniDelitelji(int a, int b) {
        // množica deliteljev števila a
		NavigableSet<Integer> deliteljiA = new TreeSet<>(delitelji(a));
		
		// množica deliteljev števila b
		NavigableSet<Integer> deliteljiB = new TreeSet<>(delitelji(b));
		
		// izračunamo presek množic
		deliteljiA.retainAll(deliteljiB);
		
		return deliteljiA;
    }

    public static Map<Integer, List<Integer>> stevilo2delitelji(int a, int b) {
		Map<Integer, List<Integer>> slovar = new HashMap<>();
		for (int i = a;  i <= b;  i++) {
			slovar.put(i, delitelji(i));
		}		
		return slovar;
    }

    public static List<Integer> prastevila(int a, int b) {
		return filtriraj(zaporedje(a, b), element -> delitelji(element).size() == 2);
    }

    public static List<Boolean> prastevilskost(int a, int b) {
        return pretvori(zaporedje(a, b), element -> delitelji(element).size() == 2);
    }

    public static List<List<Integer>> seznamiDeliteljev(int a, int b) {
        return pretvori(zaporedje(a, b), element -> delitelji(element));
    }

    public static NavigableSet<Integer> stevilaPoDeljivosti(int a, int b) {
		Map<Integer, List<Integer>> st2del = stevilo2delitelji(a, b);
		
        NavigableSet<Integer> mnozica = new TreeSet<>(
			(p, q) -> {
				int stDeliteljevP = st2del.get(p).size();
				int stDeliteljevQ = st2del.get(q).size();
				if (stDeliteljevP != stDeliteljevQ) {
					return (stDeliteljevQ - stDeliteljevP);
				}
				return (p - q);
			});
			
		mnozica.addAll(zaporedje(a, b));
		// alternativa: mnozica.addAll(st2del.keySet());
		
		return mnozica;
    }
}
