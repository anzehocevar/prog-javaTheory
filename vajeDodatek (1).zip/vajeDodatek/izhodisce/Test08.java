
public class Test08 {

    public static void main(String[] args) {
        System.out.println(Deljivost.prastevilskost(1, 10));
        System.out.println(Deljivost.prastevilskost(11, 30));
        System.out.println(Deljivost.prastevilskost(90, 96));
    }
}
