
public class Test10 {

    public static void main(String[] args) {
        System.out.println(Deljivost.stevilaPoDeljivosti(1, 10));
        System.out.println();

        System.out.println(Deljivost.stevilaPoDeljivosti(1, 100));
        System.out.println();

        System.out.println(Deljivost.stevilaPoDeljivosti(1, 1000));
        System.out.println();

        System.out.println(Deljivost.stevilaPoDeljivosti(30, 40));
        System.out.println();

        System.out.println(Deljivost.stevilaPoDeljivosti(30, 30));
        System.out.println();

        System.out.println(Deljivost.stevilaPoDeljivosti(30, 29));
        System.out.println();
    }
}
