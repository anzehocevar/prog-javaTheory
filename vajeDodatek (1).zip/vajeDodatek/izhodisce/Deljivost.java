
import java.util.*;
import java.util.function.*;

public class Deljivost {

    public static void main(String[] args) {
        // dopolnite, "ce "zelite metode testirati ro"cno
    }

    public static <T> List<T> filtriraj(Collection<T> zbirka, Predicate<T> pogoj) {
		return null;		
    }

    public static <T, R> List<R> pretvori(Collection<T> zbirka, Function<T, R> pretvornik) {
		return null;
    }

    public static List<Integer> zaporedje(int a, int b) {
		return null;
    }

    public static List<Integer> delitelji(int n) {
        return null;
    }

    public static NavigableSet<Integer> skupniDelitelji(int a, int b) {
		return null;
    }

    public static Map<Integer, List<Integer>> stevilo2delitelji(int a, int b) {
		return null;
    }

    public static List<Integer> prastevila(int a, int b) {
		return null;
    }

    public static List<Boolean> prastevilskost(int a, int b) {
		return null;
    }

    public static List<List<Integer>> seznamiDeliteljev(int a, int b) {
		return null;
    }

    public static NavigableSet<Integer> stevilaPoDeljivosti(int a, int b) {
		return null;
    }
}
