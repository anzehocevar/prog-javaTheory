
public class Test05 {

    public static void main(String[] args) {
        System.out.println(Deljivost.skupniDelitelji(36, 48));
        System.out.println(Deljivost.skupniDelitelji(840, 504));
        System.out.println(Deljivost.skupniDelitelji(50, 100));
        System.out.println(Deljivost.skupniDelitelji(25, 36));
    }
}
