
public class Test03 {

    public static void main(String[] args) {
        System.out.println(Deljivost.zaporedje(1, 10));
        System.out.println(Deljivost.zaporedje(7, 25));
        System.out.println(Deljivost.zaporedje(6, 6));
        System.out.println(Deljivost.zaporedje(6, 2));
    }
}
